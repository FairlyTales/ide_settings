import { createSelector } from 'reselect';

const #[[$selectorName$]]# = (state: State) => state;

export default createSelector(
  [],
  () => ({
    
  })
);
