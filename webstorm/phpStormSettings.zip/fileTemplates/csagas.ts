import #[[$sagas$]]# from './#[[$path$]]#';

export default [...#[[$sagas$]]#];