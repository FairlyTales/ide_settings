import { combineReducers } from 'redux';

export interface #[[$interfaceName$]]# {
  #[[$END$]]#
}

export default combineReducers({

});