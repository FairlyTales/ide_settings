import React from 'react';

interface IProps {

}

const ${NAME} = (props: IProps) => {
  const {  } = props;
  
  return (
    #[[$END$]]#
  );
};

export default ${NAME};