import React from 'react';

const ${NAME} = () => {
  return (
     #[[$END$]]#
  );
};

export default ${NAME};