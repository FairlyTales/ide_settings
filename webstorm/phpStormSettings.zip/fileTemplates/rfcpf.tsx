import React from 'react';
import selector from './selector';

interface IProps {

}

const ${NAME} = (props: IProps) => {
  const {  } = props;
  const {  } = useAppSelector(selector);
  
  return (
     #[[$END$]]#
  );
};

export default ${NAME};