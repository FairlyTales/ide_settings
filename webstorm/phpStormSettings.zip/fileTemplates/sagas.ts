import { call, put, select, takeLatest } from 'redux-saga/effects';
import * as actions from './actions';

function* #[[$firstSaga$]]#() {
  try {
   
  } catch (e) {
    yield call(responseError, e);
  }
}

export default [
  takeLatest(actions.#[[$firstSaga$]]#, #[[$firstSaga$]]#),
];
