import React from 'react';
import selector from './selector';

const ${NAME} = () => {
  const {  } = useAppSelector(selector);
  
  return (
     #[[$END$]]#
  );
};

export default ${NAME};